from django.shortcuts import render, redirect, get_object_or_404
from .models import Product
from django.utils import timezone
from django.contrib.auth.decorators import login_required

def home(request):
    products = Product.objects.order_by('-pub_date')
    return render(request,'products/home.html',{'products':products})

@login_required
def create(request):
    if request.method == 'POST':
        print('***'+request.user.username)
        print(request.user.id)
        if request.POST['title'] and request.POST['url'] and request.FILES['image']:
            product = Product()
            product.title = request.POST['title']
            if request.POST['url'].startswith('http://') or request.POST['url'].startswith('https://'):
                product.url = request.POST['url']
            else:
                product.url = 'http://' + request.POST['url']
            product.pub_date = timezone.datetime.now()
            product.hunter = request.user
            product.body = request.POST['body']
            product.image = request.FILES['image']
            product.icon = request.FILES['icon']
            product.save()
            return redirect('/products/'+ str(product.id))
        else:
            return render(request, 'products/create.html', {'error':'ERROR: You must include a title and a URL and image to create a product.'})
    else:
        return render(request, 'products/create.html')

def detail(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    return render(request, 'products/detail.html',{'product':product})

@login_required
def upvote(request, product_id):
    print('herrr')
    if request.method == 'POST':
        print('hey fam')
        product = Product.objects.get(pk=product_id)
        product.votes_total += 1
        product.save()

        if 'next' in request.POST:
                return redirect(request.POST['next'])
        return redirect('/products/'+ str(product.id))
    else:
        return redirect('/products/'+ str(product_id))
