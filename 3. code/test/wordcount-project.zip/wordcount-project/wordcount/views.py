from django.http import HttpResponse
from django.shortcuts import render
import operator

def home(request):
    return render(request, 'home.html')

def count(request):
    original = request.GET['fulltext'].lower()


    words = original.split()
    # Do this for the easy way
    #return render(request, 'count.html', {'original':original, 'count':len(words)})

    wordtotal = {}

    for word in words:
        if word in wordtotal:
            wordtotal[word] += 1
        else:
            wordtotal[word] = 1


    return render(request, 'count.html', {'original':original, 'count':len(words), 'wordtotal':sorted(wordtotal.items(),key=operator.itemgetter(1), reverse=True)})

def about(request):
    return render(request, 'about.html')
